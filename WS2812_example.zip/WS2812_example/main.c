/*
 * WS2812_example.c
 *
 * Created: 30.09.2019 14:56:06
 * Author : Dario Dündar
 */ 

#include <avr/io.h>
/*Enthält LED-Treiber und delay-Funktionen*/
#include "ws2812.h"

int main()
{
    rgb_color leds[LED_COUNT];
    
    while(1)
    {
        leds[0].red = 255;
        leds[0].green = 255;
        leds[0].blue = 255;
        
        leds[1].red = 255;
        leds[1].green = 255;
        leds[1].blue = 255;
        
        leds[2] = (rgb_color){255,255,255};
        
        led_strip_write(leds);
        _delay_ms(500);
        
        leds[0].red = 0;
        leds[0].green = 0;
        leds[0].blue = 0;
        
        leds[1].red = 0;
        leds[1].green = 0;
        leds[1].blue = 0;
        
        leds[2] = (rgb_color){0,0,0};
        
        led_strip_write(leds);
        _delay_ms(500);
    }
}

